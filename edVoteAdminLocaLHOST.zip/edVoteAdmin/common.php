<?php

/**
 * Escapes HTML for output
 *
 */

//session_start();

if (empty($_SESSION['csrf'])) {
  if (function_exists('random_bytes')) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
  } else if (function_exists('mcrypt_create_iv')) {
    $_SESSION['csrf'] = bin2hex(mcrypt_create_iv(32, MCRYPT_DEV_URANDOM));
  } else {
    $_SESSION['csrf'] = bin2hex(openssl_random_pseudo_bytes(32));
  }
}


function escape($html) {
    return htmlspecialchars($html, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
}

function abbreviate($string){
  $abbreviation = "";
  $string = ucwords($string);
  $words = explode(" ", "$string");
    foreach($words as $word){
        $abbreviation .= $word[0];
    }
 return $abbreviation; 
}


$current_date = date('Y-m-d');
?>