CREATE DATABASE edVoteDB; 

use edVoteDB;