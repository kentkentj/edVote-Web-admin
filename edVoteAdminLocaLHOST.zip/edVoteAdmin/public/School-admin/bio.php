<?php include 'templates/header.php' ?>
<?php 
try{
	require "../../config.php";
    require "../../common.php"; 
	$connection=new PDO($dsn, $username, $password, $options);

	$sql="SELECT * FROM candidatetable WHERE school_id = '$school_id'";

	$statement = $connection->prepare($sql);
  	$statement->execute();
	$result_candidates = $statement->fetchAll();

} catch(PDOException $error){
	echo $sql . "<br>" . $error->getMessage();
}


if(isset($_POST["addbio"])){
	if (!hash_equals($_SESSION['csrf'], $_POST['csrf'])) die();
	try{
		$connection = new PDO($dsn, $username, $password, $options);
        $header = explode(",", $_POST['candidate']);
		$new_user = array(
            "candidate_id" => $header[0],
            "header"  => $_POST['header'],
            "caption"     => $_POST['caption']
        );
          
        $sql = sprintf(
                "INSERT INTO %s (%s) values (%s)",
                "bio",
                implode(", ", array_keys($new_user)),
                ":" . implode(", :", array_keys($new_user))
        );
        
        $statement = $connection->prepare($sql);
        $statement->execute($new_user);
	} catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}
?>
<script src="js/upload-image.js"></script>
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4 d-flex justify-content-center">
        <div class="card w-50">
            <div class="card-body">
                <h3>Add Bio</h3>
                
                <form method="POST">
                    <div class="form-outline mb-4">
                        <input id="header" type="text" class="form-control" name="header" />
                        <label class="form-label" for="header">Header</label>
                    </div>
                    <div class="form-outline mb-4">
                        <textarea class="form-control" id="caption" rows="4" name="caption"></textarea>
                        <label class="form-label" for="caption">Message</label>
                    </div>

                    <select class="form-select my-3" name="candidate">
                        <option disabled selected>Select Candidate</option>
                        <?php foreach ($result_candidates as $row) : ?>
                            <option value="<?php echo escape($row["candidate_id"]); ?>,<?php echo escape($row["candidate_name"]); ?>">
                            <?php echo escape($row["candidate_name"]); ?> -
                            <?php echo escape($row["candidate_party"]); ?> -
                            <?php echo escape($row["candidate_position"]); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>

                    <div class="d-flex justify-content-end">
                        <input type="submit" class="btn btn-primary" name="addbio" value="ADD BIO"/>
                    </div>

                    <input name="csrf" type="hidden" value="<?php echo escape($_SESSION['csrf']); ?>">
                </form>
            </div>
        </div>

        <?php if (isset($_POST['addbio']) && $statement): ?>
            <?php $header = explode(",", $_POST['candidate']); ?>
            <div class="toast show fade mx-auto show fade text-white bg-success" id="static-example" role="alert" aria-live="assertive" aria-atomic="true" data-mdb-autohide="false">
                    <div class="toast-header text-white bg-success">
                        <strong class="me-auto">Success</strong>
                        <button type="button" class="btn-close btn-close-white btn-exit" data-mdb-dismiss="toast" aria-label="Close"></button>
                    </div>
                <div class="toast-body"><?php echo  $header[1]; ?> successfully added.</div>
            </div>
        <?php endif;?>
    </div>
</main>
  <!--Main layout-->
<?php include 'templates/footer.php' ?>