<?php include 'templates/header.php' ?>
<?php 
try{
	require "../../config.php";
    require "../../common.php"; 
	$connection=new PDO($dsn, $username, $password, $options);

	$sql="SELECT * FROM candidatetable";

	$statement = $connection->prepare($sql);
  	$statement->execute();
	$result_candidates = $statement->fetchAll();

} catch(PDOException $error){
	echo $sql . "<br>" . $error->getMessage();
}


try{
	$connection=new PDO($dsn, $username, $password, $options);

	$sql="SELECT * FROM video";

	$statement = $connection->prepare($sql);
  	$statement->execute();
	$result_video = $statement->fetchAll();

} catch(PDOException $error){
	echo $sql . "<br>" . $error->getMessage();
}

if(isset($_POST["addvideo"])){
	if (!hash_equals($_SESSION['csrf'], $_POST['csrf'])) die();
	try{
		$connection = new PDO($dsn, $username, $password, $options);

		$new_user = array(
            "candidate_id" => $_POST['candidate'],
            "video_link"  => $_POST['link'],
            "video_title"     => $_POST['title']
        );
          
        $sql = sprintf(
                "INSERT INTO %s (%s) values (%s)",
                "video",
                implode(", ", array_keys($new_user)),
                ":" . implode(", :", array_keys($new_user))
        );
        
        $statement = $connection->prepare($sql);
        $statement->execute($new_user);
	} catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}
?>
<script src="js/upload-image.js"></script>
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4 d-flex justify-content-center">
        <div class="card w-50">
            <div class="card-body">
                <h3>Add Youtube Video</h3>
                
                <form method="POST">
                    <div class="form-outline mb-4">
                        <input id="link" type="text" class="form-control" name="link" />
                        <label class="form-label" for="link">Link</label>
                    </div>
                    <div class="form-outline mb-4">
                        <input id="title" type="text" class="form-control" name="title" />
                        <label class="form-label" for="title">Title</label>
                    </div>

                    <select class="form-select my-3" name="candidate">
                        <option disabled selected>Select Candidate</option>
                        <?php foreach ($result_candidates as $row) : ?>
                            <option value="<?php echo escape($row["candidate_id"]); ?>">
                            <?php echo escape($row["candidate_name"]); ?> -
                            <?php echo escape($row["candidate_party"]); ?> -
                            <?php echo escape($row["candidate_position"]); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>

                    <div class="d-flex justify-content-end">
                        <input type="submit" class="btn btn-primary" name="addvideo" value="ADD VIDEO"/>
                    </div>

                    <input name="csrf" type="hidden" value="<?php echo escape($_SESSION['csrf']); ?>">
                </form>
            </div>
        </div>

        <?php if (isset($_POST['addvideo']) && $statement) { ?>
            <div class="ratio ratio-16x9">
                <iframe
                    src="<?php echo str_replace("watch?v=","embed/", $_POST['link']); ?>"
                    title="<?php echo $_POST['title']; ?>"
                    allowfullscreen
                ></iframe>
            </div>
        <?php }?>
    </div>
    
    <div class="container pt-4 w-75">
        <?php foreach ($result_video as $row) : ?>
        <div class="ratio ratio-16x9">
            <iframe
                src="<?php echo str_replace("watch?v=","embed/", escape($row["video_link"])); ?>"
                title="YouTube video"
                allowfullscreen></iframe>
        </div>
        <?php endforeach; ?>
    </div>
</main>
  <!--Main layout-->
<?php include 'templates/footer.php' ?>