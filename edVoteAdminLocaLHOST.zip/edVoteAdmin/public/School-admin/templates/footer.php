<!-- MDB -->
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Custom scripts -->
<!--script type="text/javascript" src="js/admin.js"></script>-->
</body>
</html>