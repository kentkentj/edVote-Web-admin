<?php include 'templates/header.php' ?>
<?php
/** * Use an HTML form to edit an entry in the * users table. * */
require "../../config.php";
require "../../common.php";

    try{
        $connection=new PDO($dsn, $username, $password, $options);
        $sql="SELECT COUNT(voters_vote_id) AS 'votes', candidate_name, candidate_position,candidate_party FROM balot_counting_table GROUP BY candidate_name ORDER BY candidate_position";
    
        $statement = $connection->prepare($sql);
        $statement->execute();
        $result = $statement->fetchAll();
    
    } catch(PDOException $error){
        echo $sql . "<br>" . $error->getMessage();
    }    

    try{
        $connection=new PDO($dsn, $username, $password, $options);
    
        $sql_read_electionevent="SELECT * FROM electionevent ORDER BY election_id DESC";
    
        $statement_read = $connection->prepare($sql_read_electionevent);
        $statement_read->execute();
        $result_election = $statement_read->fetchAll();
    
    } catch(PDOException $error){
        echo $sql_read_electionevent . "<br>" . $error->getMessage();
    }

 ?> 
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4">
      <!-- Section: Main chart -->
      <section class="mb-4">
        <div class="card">
          <div class="card-header py-3">
            <h5 class="mb-0 text-center"><strong>Election Results</strong></h5>
          </div>
          <div class="card-body">
            <canvas class="my-4 w-100" id="myChart" height="380"></canvas>
          </div>
        </div>
      </section>
      <!-- Section: Main chart -->

      <!--Section: Elections KPIs-->
      <section class="mb-4">
        <div class="card">
          <div class="card-header text-center py-3">
            <h5 class="mb-0 text-center">
              <strong>Elections</strong>
            </h5>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover text-nowrap">
                <thead>
                  <tr>
                    <th scope="col"></th>
                    <th scope="col">Available in</th>
                    <th scope="col">Due</th>
                    <th scope="col">Department</th>
                    <th scope="col">School</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach ($result_election as $row) : ?>
                  <tr>
                    <th scope="row"><?php echo escape($row["election_name"]); ?></th>
                    <td><?php echo escape($row["start_election_date"]); ?></td>
                    <td><?php echo escape($row["end_election_date"]); ?></td>
                    <td><?php echo escape($row["depatment_name"]); ?></td>
                    <td><?php echo escape($row["school_name"]); ?></td>
                    <td>
                        <a href="candidates?electionid=<?php echo escape($row["election_id"]); ?>">View</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Sales Performance KPIs-->

      <!--Section: election results-->
      <section>
        <div class="card-header text-center py-3">
          <h5 class="mb-0 text-center">
            <strong>All Election Results</strong>
          </h5>
        </div>
        <div class="row">
          <?php foreach ($result_election as $row) : ?>
          <div class="col-6">
              <div class="card">
                  <div class="card-body">
                      <div class="card text-center">
                          <div class="card-header">Start: <?php echo escape($row["start_election_date"]); ?></div>
                          <div class="card-body">
                              <h5 class="card-title"><?php echo escape($row["election_name"]); ?></h5>
                              <p class="card-text">
                                  School: <?php echo escape($row["school_name"]); ?><br>
                                  Department: <?php echo escape($row["depatment_name"]); ?>
                              </p>
                              <a href="viewelectionresult?electionid=<?php echo escape($row["election_id"]); ?>" class="btn btn-primary">View</a>
                          </div>
                          <div class="card-footer text-muted">Due: <?php echo escape($row["end_election_date"]); ?></div>
                      </div>
                  </div>
              </div>
          
          </div>
          <?php endforeach; ?>
        </div>
      </section>
      <!--Section: election results-->


    </div>
  </main>
  <!--Main layout-->

  <script>
    // Graph
    var ctx = document.getElementById("myChart");

    var xValues = [<?php foreach ($result as $row) : ?><?php echo json_encode(escape($row["candidate_name"])  . ' - ' . abbreviate(escape($row["candidate_position"]))) . ",";?><?php endforeach; ?>];
    var yValues = [<?php foreach ($result as $row) : ?><?php echo escape($row["votes"]) . ",";?><?php endforeach; ?>];


    new Chart("myChart", {
      type: "bar",
      data: {
        labels: xValues,
        datasets: [{
          backgroundColor: "#1266F1",
          data: yValues
        }]
      },
      options: {
        legend: {display: false},
        title: {
          display: true,
          text: "Current Election Results"
        }
      }
    });
  </script>
<?php include 'templates/footer.php' ?>