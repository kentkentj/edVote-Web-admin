<?php include 'templates/header.php' ?>
<?php 
try{
	require "../../config.php";
    require "../../common.php";
	$connection=new PDO($dsn, $username, $password, $options);

	$sql="SELECT * FROM depatment_table WHERE school_id = '$school_id'";

	$statement = $connection->prepare($sql);
  	$statement->execute();
	$result = $statement->fetchAll();

} catch(PDOException $error){
	echo $sql . "<br>" . $error->getMessage();
}


if(isset($_POST["create_user"])){
	//if (!hash_equals($_SESSION['csrf'], $_POST['csrf'])) die();
	try{
		$connection = new PDO($dsn, $username, $password, $options);

        $dept = explode(",", $_POST['department']);

		$new_user = array(
            "admin_employee_id" => $_POST['employeeID'],
            "full_name" => strtoupper($_POST['name']),
            "email" => $_POST['email'],
            "password" => password_hash($_POST['employeeID'], PASSWORD_DEFAULT),
            "department_id" => $dept[1],
            "depatment_name" => $dept[2],
            "depatment_name_abbreviation" => $dept[0],
            "school_id" => $_POST['employeeID'],
            "school_name" => $_POST['school'],
            "account_status" => 'active',
            "admin_type" => $_POST['adminType']            
        );

        $sql_users = sprintf(
                "INSERT INTO %s (%s) values (%s)",
                "admin_account",
                implode(", ", array_keys($new_user)),
                ":" . implode(", :", array_keys($new_user))
        );
        
        $statement = $connection->prepare($sql_users);
        $statement->execute($new_user);
	} catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}


//read users
try{
	$connection=new PDO($dsn, $username, $password, $options);

	$sql="SELECT * FROM admin_account WHERE school_id = '$school_id' AND depatment_name_abbreviation = '$department'";

	$statement = $connection->prepare($sql);
  	$statement->execute();
	$result_user = $statement->fetchAll();

} catch(PDOException $error){
	echo $sql . "<br>" . $error->getMessage();
}
?>
<script src="https://www.gstatic.com/firebasejs/4.8.1/firebase.js"></script>
<script src="js/config.js"></script>
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4">
        <h1 class="mb-3">Add New Admin User</h1>

        <?php if (isset($_POST['create_user']) && $statement) { ?>
            <div class="toast show fade mx-auto show fade text-white bg-success" id="static-example" role="alert" aria-live="assertive" aria-atomic="true" data-mdb-autohide="false">
                    <div class="toast-header text-white bg-success">
                        <strong class="me-auto">Success</strong>
                        <button type="button" class="btn-close btn-close-white btn-exit" data-mdb-dismiss="toast" aria-label="Close"></button>
                    </div>
                <div class="toast-body"><?php echo $_POST['name'] . " "; ?> successfully added.</div>
            </div>
        <?php }?>
        <div id="user_create_info" class="card my-5">
            <div class="card-body">
                <h5 class="card-title">User Information</h5>
                <form method="POST">
                    <!-- 2 column grid layout with text inputs for the first and last names -->
                    <div class="row mb-4">
                        <div class="col my-2">
                            <div class="form-outline">
                                <input type="text" id="name" class="form-control" name="name" />
                                <label class="form-label" for="name">Name</label>
                            </div>
                        </div>
                        <div class="col my-2">
                            <div class="form-outline">
                                <input type="email" id="email" class="form-control" name="email" />
                                <label class="form-label" for="email">Email</label>
                            </div>
                        </div>
                        <div class="col my-2">
                            <div class="form-outline">
                                <input type="text" id="employye" class="form-control" name="employeeID" />
                                <label class="form-label" for="suffix">Employee ID</label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <!-- id input -->
                            <div class="form-outline mb-4">
                                <input type="text" id="form6Example3" class="form-control" name="student_id" />
                                <label class="form-label" for="form6Example3">School ID</label>
                            </div>
                        </div>

                        <div class="col">
                            <!-- school input -->
                            <div class="form-outline mb-4">
                                <input type="text" id="school" class="form-control" name="school" />
                                <label class="form-label" for="school">School</label>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col">
                            <select class="form-select" aria-label="Default select example" name="department">
                                <option selected disabled>Department</option>
                                <?php foreach ($result as $row) : ?>
                                    <option value="<?php echo escape($row["depatment_name_abbreviation"]); ?>,<?php echo escape($row["department_id"]); ?>,<?php echo escape($row["depatment_name"]); ?>"><?php echo escape($row["depatment_name_abbreviation"]); ?></option>
                                <?php endforeach; ?>   
                            </select>
                        </div>
                        
                        <div class="col">
                            <select class="form-select" name="adminType">
                                <option value="administrator">School Admin</option>
                                <option value="school">Student Admin</option>
                            </select>
                        </div>
                    </div>
                    <!-- Submit button -->
                    <button type="submit" class="btn btn-secondary bg-gradient btn-block mb-4" name="create_user">CREATE USER</button>

                    <input name="csrf" type="hidden" value="<?php echo escape($_SESSION['csrf']); ?>">
                </form>
            </div>
        </div>
        
        <div class="card">
            <div class="card-body">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Full Name</th>
                <th>School</th>
                <th>Department</th>
                <th>Email</th>
                <th>Admin type</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($result_user as $row) : ?>
            <tr>
                <td><?php echo escape($row["admin_employee_id"]); ?></td>
                <td><?php echo escape($row["full_name"]); ?></td>
                <td><?php echo escape($row["school_name"]); ?></td>
                <td><?php echo escape($row["depatment_name_abbreviation"]); ?></td>
                <td><?php echo escape($row["email"]); ?></td>
                <td><?php echo escape($row["admin_type"]); ?></td>
                <td>
                    <?php if(escape($row["account_status"]) == 'active'): ?>
                        <div class="badge bg-success text-wrap" style="width: 6rem;text-transform:uppercase">
                            <?php echo escape($row["account_status"]); ?></a>
                        </div>
                    <?php else: ?>
                        <div class="badge bg-danger text-wrap" style="width: 6rem;text-transform:uppercase">
                            <?php echo escape($row["account_status"]); ?>
                        </div>
                     <?php endif; ?>
                </td>
                <td>
                    <?php if(escape($row["account_status"]) == 'active'): ?>
                        <a href="decativateadmin?account=<?php echo escape($row["admin_user_id"]); ?>" class="call-btn btn btn-outline-primary btn-floating btn-sm" ><i class="fas fa-lock"></i></a>
                    <?php else: ?>
                        <a href="activateadmin?account=<?php echo escape($row["admin_user_id"]); ?>" class="call-btn btn btn-outline-primary btn-floating btn-sm" ><i class="fas fa-lock"></i></a>                       
                    <?php endif; ?>
                    <a href="userprofile?userprofile=<?php echo escape($row["admin_user_id"]); ?>" class="message-btn btn ms-2 btn-primary btn-floating btn-sm"><i class="fas fa-marker"></i></a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Student ID</th>
                <th>Full Name</th>
                <th>School</th>
                <th>Department</th>
                <th>Year</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </tfoot>
    </table>
            </div>
        </div>
    </div>
  </main>

  <script>
    $(document).ready(function() {
        $('#example').dataTable();
    } );
  </script>
  <!--Main layout-->
<?php include 'templates/footer.php' ?>