
<?php
/** * Use an HTML form to edit an entry in the * users table. * */
require "../../config.php";
require "../../common.php";

if (isset($_GET['electionid']))
{
    try{

        $connection=new PDO($dsn, $username, $password, $options);
        $id = $_GET['electionid'];
        $sql="SELECT COUNT(voters_vote_id) AS 'votes', candidate_name, candidate_position,candidate_party FROM balot_counting_table WHERE election_id = :electionid GROUP BY candidate_name ORDER BY candidate_position";
        
        $statement = $connection->prepare($sql);
        $statement->bindValue(':electionid', $id);
        $statement->execute();
        $result = $statement->fetchAll();

        //get department color
        $sql_get_department_color="SELECT depatment_table.color, electionevent.depatment_name FROM depatment_table INNER JOIN electionevent ON depatment_table.depatment_name_abbreviation = electionevent.depatment_name WHERE electionevent.election_id = :electionid LIMIT 1";
        $statement_get_department_color = $connection->prepare($sql_get_department_color);
        $statement_get_department_color->bindValue(':electionid', $id);
        $statement_get_department_color->execute();
        $result_get_department_color = $statement_get_department_color->fetchAll();
    
    } catch(PDOException $error){
        echo $sql . "<br>" . $error->getMessage();
    }    
}
else
{
    echo "Something went wrong!";
    exit;
} ?> 
<?php include 'templates/header.php' ?>
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4">
      <!--Section: Sales Performance KPIs-->
      <section class="mb-4">
        <div class="card">
          <div class="card-body">
            <canvas class="my-4 w-100" id="myChart" height="380"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card-header text-center py-3">
            <h5 class="mb-0 text-center">
              <strong>Results of Election</strong>
            </h5>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover text-nowrap">
                <thead>
                  <tr>
                    <th scope="col"></th>
                    <th scope="col">Candidate Position</th>
                    <th scope="col">Candidate Party</th>
                    <th scope="col">Votes</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach ($result as $row) : ?>
                  <tr>
                    <th scope="row"><?php echo escape($row["candidate_name"]); ?></th>
                    <td><?php echo escape($row["candidate_position"]); ?></td>
                    <td><?php echo escape($row["candidate_party"]); ?></td>
                    <td><?php echo escape($row["votes"]); ?></td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Sales Performance KPIs-->
    </div>
  </main>
  <!--Main layout-->

  <script>
    // Graph
    var ctx = document.getElementById("myChart");

    var xValues = [<?php foreach ($result as $row) : ?><?php echo json_encode(escape($row["candidate_name"])  . ' - ' . abbreviate(escape($row["candidate_position"]))) . ",";?><?php endforeach; ?>];
    var yValues = [<?php foreach ($result as $row) : ?><?php echo escape($row["votes"]) . ",";?><?php endforeach; ?>];


    new Chart("myChart", {
      type: "bar",
      data: {
        labels: xValues,
        datasets: [{
          backgroundColor: "<?php foreach ($result_get_department_color as $row) : ?><?php echo escape($row["color"]);?><?php endforeach; ?>",
          data: yValues
        }]
      },
      options: {
        legend: {display: false},
        title: {
          display: true,
          text: "Department Election Results"
        }
      }
    });
  </script>
<?php include 'templates/footer.php' ?>