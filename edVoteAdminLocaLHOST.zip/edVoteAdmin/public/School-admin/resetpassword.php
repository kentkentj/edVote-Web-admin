<?php
/** * Use an HTML form to edit an entry in the * users table. * */
require "../../config.php";
require "../../common.php"; 
if (isset($_POST['reset']))
{
	//if (!hash_equals($_SESSION['csrf'], $_POST['csrf'])) die();
    try
    {
        $connection = new PDO($dsn, $username, $password, $options);
        $user = ["idnumber" => $_POST['idnumber'], "hash_pword" => password_hash($_POST['idnumber'], PASSWORD_DEFAULT)];
        $sql = "UPDATE studentusertable SET user_password = :hash_pword WHERE student_id = :idnumber";
        $statement = $connection->prepare($sql);
        $statement->execute($user);
    }
    catch(PDOException $error)
    {
        echo $sql . "<br>" . $error->getMessage();
    }
}
?> 
<?php include 'templates/header.php' ?>
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4 my-5">
    <?php if (isset($_POST['reset']) && $statement): ?> 
	        <?php echo escape($_POST['reset']); ?> Password Reset. 
    <?php endif; ?> 
        <div class="card">
            <div class="card-body">
                <section class="vh-100">
                    <div class="container py-5 h-100">
                        <div class="row d-flex align-items-center justify-content-center h-100">
                            <div class="col-md-8 col-lg-7 col-xl-6">
                                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.svg"
                                class="img-fluid" alt="Phone image">
                            </div>
                            <div class="col-md-7 col-lg-5 col-xl-5 offset-xl-1">
                                <form method="POST">
                                    <!-- Email input -->
                                    <div class="form-outline mb-4">
                                        <input type="text" id="form1Example13" class="form-control form-control-lg" name="idnumber"/>
                                        <label class="form-label" for="form1Example13">ID NUMBER</label>
                                    </div>
                                    
                                    <input name="csrf" type="hidden" value="<?php echo escape($_SESSION['csrf']); ?>">

                                    <!-- Submit button -->
                                    <button type="submit" class="btn btn-primary btn-lg btn-block" name="reset">Reset Password</button>
                              
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>    
    </div>
</main>


  <!--Main layout-->
<?php include 'templates/footer.php' ?>