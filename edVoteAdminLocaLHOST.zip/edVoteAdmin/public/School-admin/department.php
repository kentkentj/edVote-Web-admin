<?php include 'templates/header.php' ?>
<?php
require "../../config.php";
require "../../common.php"; 
if (isset($_GET["delete"])) {
    try {
      $connection = new PDO($dsn, $username, $password, $options);
  
      $id = $_GET["delete"];
  
      $sql = "DELETE FROM depatment_table WHERE department_id = :delete";
  
      $statement = $connection->prepare($sql);
      $statement->bindValue(':delete', $id);
      $statement->execute();
  
      $success = "User successfully deleted";
    } catch(PDOException $error) {
      echo $sql . "<br>" . $error->getMessage();
    }
}

try{
	$connection=new PDO($dsn, $username, $password, $options);

	$sql="SELECT * FROM depatment_table WHERE school_id = '$school_id'";

	$statement = $connection->prepare($sql);
  	$statement->execute();
	$result = $statement->fetchAll();

} catch(PDOException $error){
	echo $sql . "<br>" . $error->getMessage();
}
?>
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4">
    <!--Section: Department-->
        <a href="create-department-single" class="btn btn-secondary btn-rounded mb-4">UPDATE DEPARTMENT</a>
        <section class="mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                <strong>Departments</strong>
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-hover text-nowrap">
                    <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col">Department ID</th>
                        <th scope="col">Department Abbreviation</th>
                        <th scope="col">Color</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($result as $row) : ?>
                    <tr>
                        <th scope="row"><?php echo escape($row["depatment_name"]); ?></th>
                        <td><?php echo escape($row["department_id"]); ?></td>
                        <td><?php echo escape($row["depatment_name_abbreviation"]); ?></td>
                        <td>
                            <div class="badge text-wrap" style="width: 6rem;text-transform:uppercase;background-color:<?php echo escape($row["color"]); ?>;">
                            </div>
                        </td>
                        <td>
                            <a href="department?delete=<?php echo escape($row["department_id"]); ?>" class="link-danger">Delete</a>
                            <a href="updatedepartment?department_id=<?php echo escape($row["department_id"]); ?>" class="link-info ps-2">Update</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            </div>
            </div>
        </section>
      <!--Section: Department-->
    </div>
  </main>
  <!--Main layout-->
<?php include 'templates/footer.php' ?>