<?php
//activate account
require "../../config.php";
require "../../common.php";
$connection=new PDO($dsn, $username, $password, $options);
if (isset($_GET["account"])) {
    try {
      $connection = new PDO($dsn, $username, $password, $options);
  
      $id = $_GET["account"];  
      $sql_status = "UPDATE admin_account SET account_status = 'active' WHERE admin_user_id = :account";

      $statement_status_account = $connection->prepare($sql_status);
      //get ids
      $statement_status_account->bindValue(':account', $id);
      $statement_status_account->execute();
    } catch(PDOException $error) {
      echo $sql_status . "<br>" . $error->getMessage();
    }
}

header('location: admin');
?>